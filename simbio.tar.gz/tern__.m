function out = tern__(cond, x, y)
    if cond
        out = x;
    else
        out = y;
    end
end
